<?php
session_start();
session_destroy();
headder('Location:compra.html');
?>